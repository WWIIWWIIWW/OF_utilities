swirlNumber: functionObject that calculates swirl number on inclined faceZone. Tested for OpenFOAM-5.x
